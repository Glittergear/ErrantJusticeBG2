///////////////////////////////
// About the Mod
//////////////////////////////
Mod: Errant Justice
Description: Too often, criminals get away with their misdeeds due to bureaucratic 
corruption or the red tape keeping the Order of the Radiant Heart from acting. A certain 
Lathanderite priest has decided to take matters into her own hands, but she needs your 
help. This is a tale of damnation... or of redemption.

Majorly Highlighted Companions: Keldorn, Rasaad, Jaheira
Minorly Highlighted Companions: Nalia, Cernd, Yoshimo, Imoen

Highlighted Classes: Cleric, Monk, Paladin, Thief

Highlighted Skills: Charisma
Minorly Highlighted Skills: Dexterity

///////////////////////////////
// Getting Started
//////////////////////////////
Talk to Bernard. Ask if he has anything for you. Then go talk to Eloran at
the Temple of Lathander.

///////////////////////////////
// Thanks to...
//////////////////////////////
Moggadeet, for being my partner in crime and brainstorming with me
#1 Unironic Khalid Fanboy in the BG discord for helping with Eloran's name
BadAssSamus in the BG discord for letting me use Elisandran's name


///////////////////////////////
// Changelog
//////////////////////////////
1.0 Initial Release

///////////////////////////////
// New Items
//////////////////////////////
The Dagger of Silencing
	THAC0 +4 against Good, +2 against all else; 
	1d4 damage; 
	Miscast Magic on Hit
The Purified Dagger of Silencing
	THAC0 +3 against Evil, +2 against all else; 
	1d4 damage; 
	50% chance of Miscast Magic on hit
The Cannibal’s Ax
	THAC0 +3 against Humanoids, +2 against all else; standard ax damage; 
	1d4 Fire Damage
The Symbol of Lathander
	Sunray 1x/day
Eloran's Letter (good/neutral version)
Eloran's Letter (evil version)
Brega's Promise of Immunity
Agent's Encoded Documents
Bandit's Encoded Documents

///////////////////////////////
// Walkthrough
//////////////////////////////
Talk to Bernard. Ask if he has anything for you. Then go talk to Eloran at
the Temple of Lathander.

Accept her quest. She'll send you to Lady Cecilia to get her to donate
If you....
	Are a Paladin, Monk, or Cleric
	Have CHA 14 or higher
	Have Rep 13 or higher 
	Have Keldorn in the Party 
	Have Rasaad in the Party
	OR have Nalia in the party
Then Lady Cecilia will agree to donate immediately. Otherwise, she'll
send you on a small quest to fetch her dress from a tailor in Waukeen's
Promenade. Go get the dress and she will agree to start donating.

Next, Eloran will send you to Sir Elisandran in the Order of the Radiant Heart
headquarters. If you...
	Are a Paladin, Monk, or Cleric
	Have CHA 16 or higher
	Have Rep 15 or higher 
	Have Keldorn in the Party 
	OR Have Rasaad in the Party
Then Sir Elisandran will make recurring donations immediately. Otherwise,
you will have to duel Squire Tristan on his squire's behalf. Tristan will
kill you, but he'll surrender and leave if you get him below half health.

After these two quests are completed Eloran will send you to start bringing
criminals to justice (ie, killing them, usually). 

First, she'll send you after a Zhentarim Agent who can be found in the
second floor of the Crooked Crane in the City Gates area. PICK UP HIS
DAGGER AND DOCUMENTS. The Dagger will let you get your first "Redemption
Point" which will become vital in the finale of the questline. You can
purify it or not, up to you--you get the Redemption Point regardless.

Eloran will read the encoded documents very quickly. She'll send you after
a group of bandits. Before you do that, you can go to Brega to convince
him to give the bandits immunity in exchange for info if they surrender.
If you...
	Are a Paladin, Monk, or Cleric
	Have CHA 13 or higher
	Have Rep 13 or higher 
	Have Keldorn in the Party 
	OR Have Rasaad in the Party
Brega will agree to give the bandits immunity. 

When you find the bandits in the Docks District by the lighthouse-looking
building, they will talk to you. If you have Brega's Promise of Immunity,
you can convince some of them to surrender and get one Redemption Point
for doing so. Otherwise, you kill all of them. PICK UP THE ENCODED DOCUMENTS.
Return to Eloran.

Eloran can't read these documents herself, so she'll send you back to the
Docks District. Go to the Temple of Oghma and give the documents to the
Glyphscribe. Return to Eloran. 

Eloran will then send you to the Umar Hills for two simultaneous quests.
First, find and kill a cannibal halfling. And second, kill Madulf and his
group. The cannibal halfling can be found at location [168.1326]. You
don't actually have to kill Madulf and his group--if you carry their message
to the mayor of Imnesvale re:living in peace, then you can return to
Eloran and tell her that you aren't going to kill them. Depending on
your reasoning, you can get one Redemption Point.

Next, Eloran will send you to the Small Teeth Pass to kill a Shadow
Druid. If you...
	Are a Druid
	Have a CHA of 16 or higher
	Have Cernd in the Party
	OR have Jaheira in the Party
You can persuade the druid to go to the Druid Grove near Trademeet.
You can now return to Eloran. If you spared the shadow druid, depending
on your reasoning, you can get one Redemption Point.

Thanks to the decoded documents, Eloran knows where a cell of Cyricist
Shadow Thieves are. She send you to the Bridge District to go kill them. 
One of the Shadow Thieves reveals himself to be a double agent and pleads
you to let him go. You can do so, or you can kill him. Once the other
Shadow Thieves are dead, you can return to Eloran. If you spared the double
agent, you can explain why and possibly get a Redemption Point.

Next, Eloran will say that there's a Zhentarim agent somewhere in Athkatla!
You'll have to find him (he's in the back of the Mithrest Inn). He will initiate 
dialogue when he sees you. There's a plot-twist/big reveal while talking to him.
Kill him and then return to Eloran.

//////////////////////////////////
//The Finale
/////////////////////////////////
Eloran will confess to being an ex-Zhentarim agent! She defected years ago and
has been trying to redeem herself ever since. This whole questline was a way
to try to redeem herself, but she doesn't feel very redeemed at all. She thinks
she is beyond redemption, and says that your last task is to witness her death as
she takes a poison.

(1) If you are Good/Neutral aligned and have collected 4 out of 5 Redemption Points,
you can convince her that she can be redeemed, and she leaves Athkatla alive.

(2) If you are of Good/Neutral alignment, have collected 3 out of 5 Redemption Points,
AND if you...
	Are a Paladin, Monk, or Cleric
	Have CHA 16 or higher
	Have Rep 16 or higher 
	Have Keldorn in the Party 
	OR Have Rasaad in the Party
Then you can convince her that she can be redeemed and she leaves Athkatla alive.

(3) If you are of Evil alignment and have collected 3 out of 5 Redemption Points, you
can tell her that either both of you can be redeemed or neither of you can. If she
damns herself, then she's damning you at the same time. She doesn't believe that you
are beyond redemption, and so she decides that she still has a chance herself. THE
EVIL CHARNAME HAS AN OPTIONAL ALIGNMENT SHIFT TO NUETRAL. Eloran leaves Athkatla
alive.

If you are of Evil alignment and only have 1 or 2 Redemption Points, Eloran calls you
a hypocrite and says that you're both beyond redemption.

If 1-3 don't apply, then you cannot convince Eloran that she can be redeemed. She once
again asks you to kill her or she takes the poison. If you...
	Have a Dex of 16 or higher
	Have Yoshimo in your group
	Have Imoen in your group
	Have Keldorn in your group
Then you can intercept her before she takes the poison, and you can convince her to turn
herself in to Brega to be appropriately punished for her crimes.

If you cannot convince her that she is deserving of finding redemption, and if you cannot
stop her from taking the poison, then she dies.

No matter what happens, the questline is over. Congrats on completing the mod!

Thanks for playing, and I'd love to know what you think! Feel free to leave a comment on
the G3 forums or message me on Discord/the Nexus/Tumblr/wherever else I am. My username is
always "Glittergear", so if you see a Glittergear somewhere, it's me :)




